// Tengu native inference: model parameters live on the device, no network requests.
// Built against ggml-org/llama.cpp examples/simple-chat API.
#include <jni.h>
#include <android/log.h>
#include "llama.h"
#include <algorithm>
#include <mutex>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
std::mutex guard;
llama_model * model = nullptr;
std::string loaded_path;
int context_size = 2048;
bool initialized = false;

std::string string_from_jni(JNIEnv * env, jstring value) {
    if (!value) return {};
    const char * chars = env->GetStringUTFChars(value, nullptr);
    if (!chars) throw std::runtime_error("Недостаточно памяти для текста");
    std::string s(chars);
    env->ReleaseStringUTFChars(value, chars);
    return s;
}
void error_to_java(JNIEnv * env, const std::string & message) {
    jclass exception = env->FindClass("java/lang/IllegalStateException");
    if (exception) env->ThrowNew(exception, message.c_str());
}
jstring utf8_to_java(JNIEnv * env, const std::string & value) {
    if (value.size() > 2 * 1024 * 1024) throw std::runtime_error("Ответ слишком длинный");
    jbyteArray bytes = env->NewByteArray(static_cast<jsize>(value.size()));
    if (!bytes) throw std::runtime_error("Недостаточно памяти для ответа");
    env->SetByteArrayRegion(bytes, 0, static_cast<jsize>(value.size()),
                            reinterpret_cast<const jbyte *>(value.data()));
    jclass cls = env->FindClass("java/lang/String");
    jmethodID ctor = env->GetMethodID(cls, "<init>", "([BLjava/lang/String;)V");
    jstring encoding = env->NewStringUTF("UTF-8");
    auto result = static_cast<jstring>(env->NewObject(cls, ctor, bytes, encoding));
    env->DeleteLocalRef(bytes);
    env->DeleteLocalRef(encoding);
    env->DeleteLocalRef(cls);
    return result;
}
void clear_model() {
    if (model) { llama_model_free(model); model = nullptr; }
    loaded_path.clear();
}
void batch_set(llama_batch_ext * batch, const llama_token * tokens, int n, int pos) {
    llama_batch_ext_clear(batch);
    for (int i = 0; i < n; ++i) {
        int idx = llama_batch_ext_add_token(batch, 0, tokens[i]);
        llama_pos p = pos + i;
        llama_batch_ext_set_pos(batch, idx, &p);
    }
    llama_batch_ext_set_output_logits(batch, n - 1, true);
}

std::string infer(const std::vector<std::string> & roles, const std::vector<std::string> & contents, int limit) {
    if (!model) throw std::runtime_error("Сначала выбери файл модели GGUF в настройках");
    if (roles.empty() || roles.size() != contents.size() || roles.size() > 24)
        throw std::runtime_error("Некорректная история разговора");
    std::vector<llama_chat_message> messages;
    messages.reserve(roles.size());
    for (size_t i = 0; i < roles.size(); ++i) {
        if (roles[i] != "user" && roles[i] != "assistant" && roles[i] != "system")
            throw std::runtime_error("Неизвестная роль в диалоге");
        messages.push_back({roles[i].c_str(), contents[i].c_str()});
    }
    const char * tmpl = llama_model_chat_template(model, nullptr);
    if (!tmpl) throw std::runtime_error("У выбранной GGUF-модели нет шаблона диалога");
    int text_len = llama_chat_apply_template(tmpl, messages.data(), messages.size(), true, nullptr, 0);
    if (text_len <= 0 || text_len > 120000)
        throw std::runtime_error("Ошибка шаблона диалога или слишком длинный запрос");
    std::vector<char> formatted(text_len + 1);
    if (llama_chat_apply_template(tmpl, messages.data(), messages.size(), true, formatted.data(), formatted.size()) < 0)
        throw std::runtime_error("Не удалось оформить запрос для модели");
    std::string prompt(formatted.data(), text_len);
    const llama_vocab * vocab = llama_model_get_vocab(model);
    int count = -llama_tokenize(vocab, prompt.c_str(), prompt.size(), nullptr, 0, true, true);
    if (count <= 0 || count >= context_size - 48)
        throw std::runtime_error("Вопрос слишком длинный для контекста модели");
    std::vector<llama_token> tokens(count);
    if (llama_tokenize(vocab, prompt.c_str(), prompt.size(), tokens.data(), tokens.size(), true, true) < 0)
        throw std::runtime_error("Ошибка токенизации сообщения");
    limit = std::min(limit, context_size - count - 8);
    if (limit <= 0) throw std::runtime_error("Недостаточно места для ответа");

    llama_context_params params = llama_context_default_params();
    params.n_ctx = context_size;
    params.n_batch = 256;
    params.n_ubatch = 256;
    params.n_threads = 3;
    llama_context * ctx = llama_init_from_model(model, params);
    if (!ctx) throw std::runtime_error("Не удалось выделить память для модели");
    llama_batch_ext * batch = nullptr;
    llama_sampler * sampler = nullptr;
    try {
        batch = llama_batch_ext_init(ctx);
        if (!batch) throw std::runtime_error("Ошибка подготовки токенов");
        sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
        llama_sampler_chain_add(sampler, llama_sampler_init_min_p(0.05f, 1));
        llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.65f));
        llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
        int pos = 0;
        while (pos < count) {
            int take = std::min(256, count - pos);
            batch_set(batch, tokens.data() + pos, take, pos);
            if (llama_process(ctx, LLAMA_PROCESS_TYPE_DECODE, batch) != 0)
                throw std::runtime_error("Ошибка вычисления запроса");
            pos += take;
        }
        std::string output;
        for (int i = 0; i < limit; ++i) {
            llama_token next = llama_sampler_sample(sampler, ctx, -1);
            if (llama_vocab_is_eog(vocab, next)) break;
            char piece[512];
            int length = llama_token_to_piece(vocab, next, piece, sizeof(piece), 0, true);
            if (length < 0) {
                std::vector<char> larger(static_cast<size_t>(-length));
                int actual = llama_token_to_piece(vocab, next, larger.data(), larger.size(), 0, true);
                if (actual > 0) output.append(larger.data(), actual);
            } else if (length > 0) output.append(piece, length);
            if (i + 1 == limit) break;
            batch_set(batch, &next, 1, pos++);
            if (llama_process(ctx, LLAMA_PROCESS_TYPE_DECODE, batch) != 0)
                throw std::runtime_error("Ошибка вычисления ответа");
        }
        if (sampler) llama_sampler_free(sampler);
        if (batch) llama_batch_ext_free(batch);
        llama_free(ctx);
        if (output.empty()) throw std::runtime_error("Модель вернула пустой ответ");
        return output;
    } catch (...) {
        if (sampler) llama_sampler_free(sampler);
        if (batch) llama_batch_ext_free(batch);
        llama_free(ctx);
        throw;
    }
}
} // namespace

extern "C" JNIEXPORT jstring JNICALL
Java_app_tengu_assistant_LocalLlm_load(JNIEnv * env, jclass, jstring jpath, jint ctx_tokens) {
    std::lock_guard<std::mutex> lock(guard);
    try {
        std::string path = string_from_jni(env, jpath);
        int ctx = std::max(512, std::min(4096, static_cast<int>(ctx_tokens)));
        if (model && loaded_path == path && context_size == ctx) return env->NewStringUTF("");
        if (!initialized) { llama_backend_init(); initialized = true; }
        clear_model();
        llama_model_params params = llama_model_default_params();
        params.n_gpu_layers = 0; // Compatibility-first: CPU only
        model = llama_model_load_from_file(path.c_str(), params);
        if (!model) throw std::runtime_error("Файл GGUF не открылся или не хватает оперативной памяти");
        loaded_path = path;
        context_size = ctx;
        return env->NewStringUTF("");
    } catch (const std::exception & ex) {
        clear_model();
        return env->NewStringUTF(ex.what());
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_app_tengu_assistant_LocalLlm_generate(JNIEnv * env, jclass, jobjectArray jroles, jobjectArray jcontents, jint max_tokens) {
    std::lock_guard<std::mutex> lock(guard);
    try {
        jsize length = env->GetArrayLength(jroles);
        if (length != env->GetArrayLength(jcontents) || length > 24 || length == 0)
            throw std::runtime_error("Неверные данные диалога");
        std::vector<std::string> roles, contents;
        roles.reserve(length); contents.reserve(length);
        for (jsize i = 0; i < length; ++i) {
            auto r = static_cast<jstring>(env->GetObjectArrayElement(jroles, i));
            auto c = static_cast<jstring>(env->GetObjectArrayElement(jcontents, i));
            roles.push_back(string_from_jni(env, r)); contents.push_back(string_from_jni(env, c));
            env->DeleteLocalRef(r); env->DeleteLocalRef(c);
        }
        auto output = infer(roles, contents, std::max(32, std::min(800, static_cast<int>(max_tokens))));
        return utf8_to_java(env, output);
    } catch (const std::exception & ex) { error_to_java(env, ex.what()); return nullptr; }
}

extern "C" JNIEXPORT void JNICALL
Java_app_tengu_assistant_LocalLlm_unload(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(guard);
    clear_model();
}
