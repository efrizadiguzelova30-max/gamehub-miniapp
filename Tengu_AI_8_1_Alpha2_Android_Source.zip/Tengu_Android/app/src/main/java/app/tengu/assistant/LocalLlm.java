package app.tengu.assistant;

/** JNI entrypoints for a genuine on-device GGUF model, not an HTTP proxy. */
final class LocalLlm {
    static final boolean AVAILABLE;
    static {
        boolean ready;
        try { System.loadLibrary("tengu_native"); ready = true; }
        catch (UnsatisfiedLinkError ex) { ready = false; }
        AVAILABLE = ready;
    }
    private LocalLlm() {}
    static native String load(String absoluteFile, int contextTokens);
    static native String generate(String[] roles, String[] contents, int maxTokens);
    static native void unload();
}
