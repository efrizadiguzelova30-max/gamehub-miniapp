package app.tengu.assistant;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.media.MediaPlayer;
import android.content.SharedPreferences;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import org.json.JSONArray;
import android.util.Log;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 9017;
    private static final int PICK_AUDIO = 9018;
    private static final int PICK_MODEL = 9019;
    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private WebView web;
    private MediaPlayer backgroundMusic;
    private ValueCallback<Uri[]> pendingFiles;
    private final ExecutorService engineQueue = Executors.newSingleThreadExecutor();
    private static final String MODEL_NAME = "tengu-model.gguf";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(250,248,243));
        getWindow().setNavigationBarColor(Color.rgb(250,248,243));
        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(
                    android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(250,248,243));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setDefaultTextEncodingName("UTF-8");
        if (Build.VERSION.SDK_INT >= 21) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        // Native methods are reachable from JS frames; disallow remote iframe contents.
        web.addJavascriptInterface(new TenguBridge(), "TenguNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !ASSET_HOST.equals(uri.getHost())) return null;
                String path = uri.getEncodedPath();
                if (path == null || !path.startsWith("/assets/")) return null;
                try {
                    String relative = URLDecoder.decode(path.substring(8), "UTF-8");
                    if (relative.startsWith("/") || relative.contains("..") || relative.contains("\\")) return null;
                    InputStream in = getAssets().open(relative, AssetManager.ACCESS_STREAMING);
                    String mime = "application/octet-stream";
                    if (relative.endsWith(".html")) mime="text/html";
                    else if (relative.endsWith(".jpg") || relative.endsWith(".jpeg")) mime="image/jpeg";
                    else if (relative.endsWith(".png")) mime="image/png";
                    else if (relative.endsWith(".svg")) mime="image/svg+xml";
                    else if (relative.endsWith(".css")) mime="text/css";
                    else if (relative.endsWith(".js")) mime="application/javascript";
                    else if (relative.endsWith(".json")) mime="application/json";
                    return new WebResourceResponse(mime, "UTF-8", in);
                } catch (Exception e) { return null; }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (ASSET_HOST.equals(uri.getHost())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); }
                    catch (Exception e) { Toast.makeText(MainActivity.this,"Нет приложения для открытия ссылки",Toast.LENGTH_SHORT).show(); }
                    return true;
                }
                return false;
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view,url);
                if (url.startsWith("https://" + ASSET_HOST + "/assets/")) {
                    installDownloadSupport();
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFiles != null) pendingFiles.onReceiveValue(null);
                pendingFiles = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, PICK_FILE);
                    return true;
                } catch (Exception e) {
                    pendingFiles.onReceiveValue(null);
                    pendingFiles=null;
                    Toast.makeText(MainActivity.this,"Не удалось открыть выбор фото",Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
            @Override public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view,title);
            }
        });
        setContentView(web);
        web.loadUrl("https://" + ASSET_HOST + "/assets/index.html");
        if (prefs().getBoolean("musicEnabled", false)) startSavedMusic();
    }

    private void installDownloadSupport(){
        // Browser blob: downloads cannot be handled by Android DownloadManager.
        // Intercept only local generated files; all other clicks retain normal behavior.
        String script = "(function(){if(window.__tenguNativeDownloads)return;window.__tenguNativeDownloads=true;"+
          "var click=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){"+
          "var a=this;if(a.download&&a.href&&a.href.indexOf('blob:')===0){"+
          "fetch(a.href).then(function(r){return r.blob()}).then(function(b){"+
          "var fr=new FileReader();fr.onload=function(){window.TenguNative.saveDataUrl(fr.result,a.download)};"+
          "fr.readAsDataURL(b)}).catch(function(e){console.error('Tengu save failed',e)});return;}"+
          "return click.call(a);};})();";
        web.evaluateJavascript(script,null);
    }

    private SharedPreferences prefs() { return getSharedPreferences("tengu", MODE_PRIVATE); }

    private void openMusicPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("audio/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, PICK_AUDIO); }
        catch (Exception ex) { notifyUser("Не удалось открыть выбор музыки"); }
    }

    private void stopMusic() {
        if (backgroundMusic != null) {
            try { backgroundMusic.stop(); } catch (Exception ignored) {}
            backgroundMusic.release(); backgroundMusic = null;
        }
    }

    private void startSavedMusic() {
        stopMusic();
        if (!prefs().getBoolean("musicEnabled", false)) return;
        String uri = prefs().getString("musicUri", "");
        if (uri.isEmpty()) return;
        try {
            MediaPlayer p = new MediaPlayer();
            p.setDataSource(this, Uri.parse(uri));
            p.setLooping(true);
            p.setVolume(0.25f, 0.25f);
            p.setOnPreparedListener(MediaPlayer::start);
            p.setOnErrorListener((mp, what, extra) -> { notifyUser("Ошибка воспроизведения музыки"); return true; });
            backgroundMusic = p;
            p.prepareAsync();
        } catch (Exception e) { notifyUser("Не удалось открыть выбранную музыку"); stopMusic(); }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == PICK_AUDIO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) {}
            prefs().edit().putString("musicUri",uri.toString()).putBoolean("musicEnabled",true).apply();
            startSavedMusic(); notifyUser("Музыка выбрана. Её можно отключить в настройках.");
        }
        if (requestCode == PICK_MODEL && resultCode == RESULT_OK && data != null && data.getData() != null) {
            importModel(data.getData());
        }
        if(requestCode==PICK_FILE && pendingFiles!=null){
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode,data);
            pendingFiles.onReceiveValue(result);
            pendingFiles=null;
        }
    }

    /** Local text inference ONLY. The target address is fixed and cannot be supplied by web JavaScript. */
    private File modelFile() { return new File(new File(getFilesDir(), "models"), MODEL_NAME); }

    private void openModelPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(intent, PICK_MODEL); }
        catch (Exception ex) { notifyUser("Не удалось открыть выбор GGUF"); }
    }

    /** Copy the user's GGUF into app-private storage. The old model remains until a complete copy. */
    private void importModel(Uri source) {
        engineQueue.execute(() -> {
            File destination = modelFile();
            File folder = destination.getParentFile();
            File temp = new File(folder, MODEL_NAME + ".partial");
            long total = 0;
            try {
                if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Нет папки модели");
                if (temp.exists()) temp.delete();
                try (InputStream input = getContentResolver().openInputStream(source);
                     OutputStream output = new FileOutputStream(temp)) {
                    if (input == null) throw new IllegalStateException("Не удалось открыть файл");
                    byte[] buffer = new byte[256 * 1024];
                    int n;
                    while ((n = input.read(buffer)) != -1) {
                        total += n;
                        if (total > 6L * 1024 * 1024 * 1024) throw new IllegalStateException("Модель больше 6 ГБ");
                        output.write(buffer, 0, n);
                    }
                }
                if (total < 1024 * 1024) throw new IllegalStateException("Слишком маленькая модель GGUF");
                try (InputStream header = new java.io.FileInputStream(temp)) {
                    byte[] magic = new byte[4];
                    if (header.read(magic) != 4 || magic[0] != 'G' || magic[1] != 'G' || magic[2] != 'U' || magic[3] != 'F') {
                        throw new IllegalStateException("Выбранный файл не является GGUF");
                    }
                }
                if (LocalLlm.AVAILABLE) LocalLlm.unload();
                // Rename atomically within the same app-private volume.
                if (!temp.renameTo(destination)) {
                    java.nio.file.Files.move(temp.toPath(), destination.toPath(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }
                prefs().edit().putString("modelImported", destination.getName()).apply();
                notifyUser("GGUF импортирована: " + (total / 1024 / 1024) + " МБ. Можно задавать вопросы.");
            } catch (Exception ex) {
                temp.delete();
                notifyUser("Импорт модели не удался: " + ex.getMessage());
            }
        });
    }

    /** Inference is fully on-device through JNI. No HTTP requests are made for chat. */
    private String talkToLocalEngine(String payloadJson) throws Exception {
        if (!LocalLlm.AVAILABLE) throw new IllegalStateException("Нативная библиотека ИИ отсутствует в APK");
        File file = modelFile();
        if (!file.isFile()) throw new IllegalStateException("Выбери GGUF-модель в настройках Tengu");
        JSONObject payload = new JSONObject(payloadJson);
        JSONArray requested = payload.optJSONArray("messages");
        if (requested == null || requested.length() < 2 || requested.length() > 24)
            throw new IllegalArgumentException("Некорректная история диалога");
        String[] roles = new String[requested.length()];
        String[] contents = new String[requested.length()];
        for (int i = 0; i < requested.length(); i++) {
            JSONObject msg = requested.getJSONObject(i);
            String role = msg.optString("role", "");
            String content = msg.optString("content", "");
            if (!(role.equals("system") || role.equals("assistant") || role.equals("user")) || content.length() > 12000)
                throw new IllegalArgumentException("Некорректное сообщение или слишком длинный контекст");
            roles[i] = role; contents[i] = content;
        }
        int tokens = Math.max(32, Math.min(800, payload.optInt("max_tokens", 350)));
        int context = tokens > 450 ? 4096 : 2048;
        String error = LocalLlm.load(file.getAbsolutePath(), context);
        if (!error.isEmpty()) throw new IllegalStateException(error);
        String output = LocalLlm.generate(roles, contents, tokens);
        if (output == null || output.trim().isEmpty()) throw new IllegalStateException("Модель не вернула текст");
        return output;
    }

    private void replyToJs(String requestId, JSONObject reply) {
        if (!requestId.matches("t[0-9]{1,12}")) return;
        String js = "window.TenguRuntime&&window.TenguRuntime._respond(" + JSONObject.quote(requestId) + "," + JSONObject.quote(reply.toString()) + ");";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private class TenguBridge {
        @JavascriptInterface public boolean musicEnabled() { return prefs().getBoolean("musicEnabled",false); }
        @JavascriptInterface public boolean musicConfigured() { return !prefs().getString("musicUri","").isEmpty(); }
        @JavascriptInterface public void pickMusic() { runOnUiThread(() -> openMusicPicker()); }
        @JavascriptInterface public void setMusicEnabled(boolean enabled) {
            prefs().edit().putBoolean("musicEnabled",enabled).apply();
            runOnUiThread(() -> { if(enabled)startSavedMusic();else stopMusic(); });
        }

        @JavascriptInterface public void localGenerate(String requestId, String payload) {
            if (requestId == null || !requestId.matches("t[0-9]{1,12}")) return;
            engineQueue.execute(() -> {
                JSONObject result = new JSONObject();
                try {
                    String answer = talkToLocalEngine(payload);
                    result.put("ok", true);
                    result.put("text", answer);
                } catch (Exception ex) {
                    try { result.put("ok", false); result.put("error", "Tengu не смогла сформировать локальный ответ. " + ex.getMessage()); }
                    catch (Exception ignored) { }
                }
                replyToJs(requestId, result);
            });
        }
        @JavascriptInterface public void pickModel() { runOnUiThread(() -> openModelPicker()); }
        @JavascriptInterface public String modelName() {
            File model = modelFile();
            return model.isFile() ? "GGUF · " + (model.length() / 1024 / 1024) + " МБ" : "Модель не импортирована";
        }
        @JavascriptInterface public void localStatus(String requestId, String unused) {
            if (requestId == null || !requestId.matches("t[0-9]{1,12}")) return;
            engineQueue.execute(() -> {
                JSONObject response = new JSONObject();
                try {
                    if (!LocalLlm.AVAILABLE) throw new IllegalStateException("Нативная библиотека отсутствует");
                    if (!modelFile().isFile()) throw new IllegalStateException("GGUF не выбрана в настройках");
                    response.put("ok", true);
                    response.put("message", "Локальный движок встроен. " + (modelFile().length() / 1024 / 1024) + " МБ GGUF на телефоне");
                } catch(Exception ex) {
                    try { response.put("ok", false); response.put("error", ex.getMessage()); }
                    catch(Exception ignored) { }
                }
                replyToJs(requestId, response);
            });
        }
        @JavascriptInterface public void saveDataUrl(String url,String requestedName) {
            if (url == null || !url.startsWith("data:") || url.length() > 100_000_000) {
                notifyUser("Файл слишком большой или неверный формат"); return;
            }
            try {
                int comma=url.indexOf(',');
                if(comma<0)throw new IllegalArgumentException("Некорректный файл");
                String metadata=url.substring(5,comma);
                String mime=metadata.split(";",2)[0];
                if(mime.isEmpty())mime="application/octet-stream";
                byte[] bytes=android.util.Base64.decode(url.substring(comma+1), android.util.Base64.DEFAULT);
                String safe=(requestedName==null?"":requestedName).replaceAll("[^a-zA-Z0-9А-Яа-яЁё_.() -]","_");
                if(safe.isEmpty())safe="Tengu_export_"+System.currentTimeMillis();
                if(Build.VERSION.SDK_INT >= 29){
                    ContentValues values=new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME,safe);
                    values.put(MediaStore.MediaColumns.MIME_TYPE,mime);
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Tengu");
                    Uri destination=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                    if(destination==null)throw new IllegalStateException("Нет доступа к загрузкам");
                    try(OutputStream stream=getContentResolver().openOutputStream(destination)){
                        if(stream==null)throw new IllegalStateException("Не удалось открыть файл");
                        stream.write(bytes);
                    }
                    notifyUser("Сохранено в Загрузки/Tengu: "+safe);
                }else{
                    File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"Tengu");
                    if(!dir.exists() && !dir.mkdirs())throw new IllegalStateException("Нет папки");
                    try(FileOutputStream out=new FileOutputStream(new File(dir,safe))){out.write(bytes);}
                    notifyUser("Сохранено в папку Tengu приложения: "+safe);
                }
            } catch(Exception e){ Log.e("Tengu","Save failed",e);notifyUser("Ошибка сохранения: "+e.getMessage()); }
        }
    }
    private void notifyUser(String message){ runOnUiThread(()->Toast.makeText(this,message,Toast.LENGTH_LONG).show()); }
    @Override public void onBackPressed() {
        new AlertDialog.Builder(this).setTitle("Выйти из Tengu?")
                .setNegativeButton("Остаться",(dialog,which)->dialog.dismiss())
                .setPositiveButton("Выйти",(dialog,which)->finish()).show();
    }
    @Override protected void onDestroy(){
        if(pendingFiles!=null){pendingFiles.onReceiveValue(null);pendingFiles=null;}
        if(web!=null){web.removeJavascriptInterface("TenguNative");web.destroy();}
        engineQueue.shutdownNow();
        stopMusic();
        super.onDestroy();
    }
}
