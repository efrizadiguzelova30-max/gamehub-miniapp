#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bash tools/get_llama_cpp.sh
if command -v gradle >/dev/null 2>&1; then
  gradle :app:assembleDebug
else
  echo 'Требуется Gradle 8.7 и Android SDK (API 35). Откройте проект в Android Studio.'
  exit 1
fi
printf '\nГотовый APK: app/build/outputs/apk/debug/app-debug.apk\n'
