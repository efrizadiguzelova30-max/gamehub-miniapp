package org.gradle.wrapper;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;

/** Transparent Gradle 8.7 launcher bootstrap (not the official Gradle wrapper). */
public final class GradleWrapperMain {
    private static final String VERSION = "8.7";
    private static final String SOURCE = "https://services.gradle.org/distributions/gradle-8.7-bin.zip";
    public static void main(String[] args) throws Exception {
        Path root = Paths.get(System.getProperty("user.dir")).toAbsolutePath();
        Path cache = root.resolve(".gradle-dist");
        Path home = cache.resolve("gradle-" + VERSION);
        boolean win = System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
        Path exe = home.resolve("bin").resolve(win ? "gradle.bat" : "gradle");
        if (!Files.exists(exe)) {
            Files.createDirectories(cache);
            Path temp = Files.createTempFile(cache, "gradle-", ".zip");
            try {
                System.out.println("Загрузка Gradle " + VERSION + " (официальный HTTPS-сайт Gradle)...");
                URLConnection c = new URL(SOURCE).openConnection();
                c.setConnectTimeout(20000);
                c.setReadTimeout(180000);
                try (InputStream in = c.getInputStream()) {
                    Files.copy(in, temp, StandardCopyOption.REPLACE_EXISTING);
                }
                System.out.println("Проверка контрольной суммы Gradle...");
                URLConnection hashConn = new URL(SOURCE + ".sha256").openConnection();
                hashConn.setConnectTimeout(20000);
                hashConn.setReadTimeout(20000);
                String expected;
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(hashConn.getInputStream(), "UTF-8"))) {
                    expected = reader.readLine().trim().split("\\s+")[0];
                }
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                try(InputStream in=Files.newInputStream(temp)) {
                    byte[] bytes = new byte[65536]; int n;
                    while((n=in.read(bytes))!=-1)digest.update(bytes,0,n);
                }
                StringBuilder actual=new StringBuilder();
                for(byte v:digest.digest()) actual.append(String.format("%02x",v & 0xff));
                if(!actual.toString().equalsIgnoreCase(expected))throw new SecurityException("Контрольная сумма Gradle не совпала");
                System.out.println("Распаковка Gradle...");
                try(ZipInputStream zip = new ZipInputStream(Files.newInputStream(temp))) {
                    ZipEntry entry;
                    while((entry=zip.getNextEntry())!=null){
                        Path dst=cache.resolve(entry.getName()).normalize();
                        if(!dst.startsWith(cache))throw new SecurityException("Недопустимый путь в архиве");
                        if(entry.isDirectory()){Files.createDirectories(dst);continue;}
                        Files.createDirectories(dst.getParent());
                        try(OutputStream out=Files.newOutputStream(dst)){byte[] b=new byte[65536];int n;while((n=zip.read(b))!=-1)out.write(b,0,n);}
                    }
                }
                if(!win) exe.toFile().setExecutable(true);
            } finally {Files.deleteIfExists(temp);}
        }
        if(!Files.exists(exe))throw new IllegalStateException("Gradle не распаковался: " + exe);
        List<String> command = new ArrayList<String>();
        if(win){command.add("cmd");command.add("/c");}
        command.add(exe.toString());
        command.addAll(Arrays.asList(args));
        Process process = new ProcessBuilder(command).directory(root.toFile()).inheritIO().start();
        System.exit(process.waitFor());
    }
}
