const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const src=fs.readFileSync('app/src/main/assets/tengu-runtime.js','utf8');
async function test(){
 let actualRequest=null;
 const window={};
 const ctx=vm.createContext({window, Map, Promise, Error, JSON, DOMException, setTimeout, clearTimeout});
 window.TenguNative={
   localGenerate(id,payload){
     actualRequest=JSON.parse(payload);
     setTimeout(()=>window.TenguRuntime._respond(id,JSON.stringify({ok:true,text:'Привет! Это локальный ответ.'})),0);
   },
   localStatus(id){
     setTimeout(()=>window.TenguRuntime._respond(id,JSON.stringify({ok:true,message:'локальный сервер доступен'})),0);
   }
 };
 vm.runInContext(src,ctx);
 const answer=await window.TenguRuntime.complete([{role:'system',content:'отвечай на русском'},{role:'user',content:'Привет'}],120);
 assert.equal(answer.text,'Привет! Это локальный ответ.');
 assert.equal(actualRequest.max_tokens,120);
 assert.equal(actualRequest.messages[1].content,'Привет');
 const status=await window.TenguRuntime.status();
 assert.equal(status.ok,true);
 delete window.TenguNative;
 await assert.rejects(window.TenguRuntime.complete([],20),/Android-приложения/);
 console.log('PASS: async local replies, message structure, diagnostics, missing engine.');
}
test().catch(e=>{console.error(e);process.exitCode=1});
