#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ -f vendor/llama.cpp/CMakeLists.txt ]]; then
  echo "llama.cpp source already present"
else
  mkdir -p vendor
  git clone --depth 1 https://github.com/ggml-org/llama.cpp.git vendor/llama.cpp
fi
printf 'llama.cpp source: ' && (cd vendor/llama.cpp && git rev-parse --short HEAD)
