#!/usr/bin/env python3
"""Download an actual CC0 tengu-mask photograph from Wikimedia Commons.
Run before compiling the APK. Dependencies: Pillow. Uses network only during build.
License: Daderot, CC0 1.0 — see AVATAR_SOURCE.txt.
"""
from pathlib import Path
from PIL import Image, ImageOps
from urllib.request import Request, urlopen
from io import BytesIO

ROOT=Path(__file__).resolve().parents[1]
URL=(
 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/'
 'Tengu_somen_%28full-face_mask%29%2C_Japan%2C_Edo_period%2C_mid_1800s_AD%2C_iron%2C_lacquer%2C_leather%2C_hemp%2C_brocade_-_The_Ann_and_Gabriel_Barbier-Mueller_Museum_-_DSC05584.jpg/'
 '500px-Tengu_somen_%28full-face_mask%29%2C_Japan%2C_Edo_period%2C_mid_1800s_AD%2C_iron%2C_lacquer%2C_leather%2C_hemp%2C_brocade_-_The_Ann_and_Gabriel_Barbier-Mueller_Museum_-_DSC05584.jpg'
)
req=Request(URL,headers={'User-Agent':'TenguAndroidBuild/0.1 (open-source asset attribution)'})
with urlopen(req,timeout=30) as r:
    raw=r.read(1_500_000)
photo=Image.open(BytesIO(raw)).convert('RGB')
for density,size in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
    # Crop the centered museum exhibit (a real Japanese tengu mask, not an emoji).
    img=ImageOps.fit(photo,(size,size),Image.Resampling.LANCZOS,centering=(0.5,0.3))
    target=ROOT/'app/src/main/res'/('mipmap-'+density)/'ic_launcher.png'
    img.save(target,optimize=True)
print('Installed CC0 tengu photographic launcher icons')
