/* Tengu on-device LLM client. The Android APK embeds llama.cpp. Import a GGUF file once.
 * Text prompts are never sent to an external service.
 * No cloud text-model fallback is provided.
 */
(function () {
  'use strict';
  let sequence = 0;
  const pending = new Map();
  const native = () => window.TenguNative;
  function createRequest(name, data, signal, timeoutMs) {
    if (!native() || typeof native()[name] !== 'function') {
      return Promise.reject(new Error('Локальный ИИ-движок доступен только внутри Android-приложения Tengu.'));
    }
    if (signal && signal.aborted) return Promise.reject(new DOMException('Отменено', 'AbortError'));
    return new Promise((resolve, reject) => {
      const id = 't' + (++sequence);
      const entry = { resolve, reject, timer: null, abort: null };
      const cleanup = () => {
        clearTimeout(entry.timer);
        if (signal && entry.abort) signal.removeEventListener('abort', entry.abort);
        pending.delete(id);
      };
      entry.resolve = (value) => { cleanup(); resolve(value); };
      entry.reject = (error) => { cleanup(); reject(error); };
      entry.abort = () => entry.reject(new DOMException('Отменено', 'AbortError'));
      if (signal) signal.addEventListener('abort', entry.abort, { once: true });
      entry.timer = setTimeout(() => entry.reject(new Error('Локальная модель не ответила вовремя.')), timeoutMs);
      pending.set(id, entry);
      try { native()[name](id, JSON.stringify(data || {})); }
      catch (error) { entry.reject(error); }
    });
  }
  window.TenguRuntime = {
    /** Called only by MainActivity after the background native operation. */
    _respond(id, resultJson) {
      const entry = pending.get(id);
      if (!entry) return;
      try {
        const result = JSON.parse(resultJson);
        if (!result.ok) entry.reject(new Error(result.error || 'Локальная модель недоступна'));
        else entry.resolve(result);
      } catch (e) { entry.reject(new Error('Неправильный ответ локального движка')); }
    },
    complete(messages, maxTokens, signal) {
      return createRequest('localGenerate', { messages, max_tokens: maxTokens }, signal, 150000);
    },
    status() {
      return createRequest('localStatus', {}, null, 60000);
    },
    http(url, opts={}, signal) {
      return createRequest('nativeHttp', {url, method:opts.method||'GET', body:opts.body||''}, signal, 45000).then(result=>({
        ok:result.status>=200 && result.status<300,
        status:result.status,
        json:async()=>JSON.parse(result.body)
      }));
    }
  };
})();
