package app.tengu.assistant;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.media.MediaPlayer;
import android.content.SharedPreferences;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URI;
import java.security.MessageDigest;
import java.security.DigestInputStream;
import android.os.StatFs;
import android.content.ActivityNotFoundException;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import org.json.JSONArray;
import android.util.Log;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 9017;
    private static final int PICK_AUDIO = 9018;
    private static final int PICK_MODEL = 9019;
    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private WebView web;
    private MediaPlayer backgroundMusic;
    private ValueCallback<Uri[]> pendingFiles;
    private final ExecutorService engineQueue = Executors.newSingleThreadExecutor();
    private final ExecutorService networkQueue = Executors.newFixedThreadPool(2);
    private volatile boolean isDownloadingModel = false;
    private static final long OFFICIAL_MODEL_SIZE = 491400032L;
    private static final String OFFICIAL_MODEL_SHA = "74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db";
    private static final String OFFICIAL_MODEL_URL = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf";

    private static final String MODEL_NAME = "tengu-model.gguf";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(250,248,243));
        getWindow().setNavigationBarColor(Color.rgb(250,248,243));
        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(
                    android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(250,248,243));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setDefaultTextEncodingName("UTF-8");
        if (Build.VERSION.SDK_INT >= 21) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        // Native methods are reachable from JS frames; disallow remote iframe contents.
        web.addJavascriptInterface(new TenguBridge(), "TenguNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !ASSET_HOST.equals(uri.getHost())) return null;
                String path = uri.getEncodedPath();
                if (path == null || !path.startsWith("/assets/")) return null;
                try {
                    String relative = URLDecoder.decode(path.substring(8), "UTF-8");
                    if (relative.startsWith("/") || relative.contains("..") || relative.contains("\\")) return null;
                    InputStream in = getAssets().open(relative, AssetManager.ACCESS_STREAMING);
                    String mime = "application/octet-stream";
                    if (relative.endsWith(".html")) mime="text/html";
                    else if (relative.endsWith(".jpg") || relative.endsWith(".jpeg")) mime="image/jpeg";
                    else if (relative.endsWith(".png")) mime="image/png";
                    else if (relative.endsWith(".svg")) mime="image/svg+xml";
                    else if (relative.endsWith(".css")) mime="text/css";
                    else if (relative.endsWith(".js")) mime="application/javascript";
                    else if (relative.endsWith(".json")) mime="application/json";
                    return new WebResourceResponse(mime, "UTF-8", in);
                } catch (Exception e) { return null; }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (ASSET_HOST.equals(uri.getHost())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); }
                    catch (Exception e) { Toast.makeText(MainActivity.this,"Нет приложения для открытия ссылки",Toast.LENGTH_SHORT).show(); }
                    return true;
                }
                return false;
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view,url);
                if (url.startsWith("https://" + ASSET_HOST + "/assets/")) {
                    installDownloadSupport();
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFiles != null) pendingFiles.onReceiveValue(null);
                pendingFiles = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, PICK_FILE);
                    return true;
                } catch (Exception e) {
                    pendingFiles.onReceiveValue(null);
                    pendingFiles=null;
                    Toast.makeText(MainActivity.this,"Не удалось открыть выбор фото",Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
            @Override public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view,title);
            }
        });
        setContentView(web);
        web.loadUrl("https://" + ASSET_HOST + "/assets/index.html");
        if (prefs().getBoolean("musicEnabled", true)) startSavedMusic();
    }

    private void installDownloadSupport(){
        // Browser blob: downloads cannot be handled by Android DownloadManager.
        // Intercept only local generated files; all other clicks retain normal behavior.
        String script = "(function(){if(window.__tenguNativeDownloads)return;window.__tenguNativeDownloads=true;"+
          "var click=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){"+
          "var a=this;if(a.download&&a.href&&a.href.indexOf('blob:')===0){"+
          "fetch(a.href).then(function(r){return r.blob()}).then(function(b){"+
          "var fr=new FileReader();fr.onload=function(){window.TenguNative.saveDataUrl(fr.result,a.download)};"+
          "fr.readAsDataURL(b)}).catch(function(e){console.error('Tengu save failed',e)});return;}"+
          "return click.call(a);};})();";
        web.evaluateJavascript(script,null);
    }

    private SharedPreferences prefs() { return getSharedPreferences("tengu", MODE_PRIVATE); }

    private void openMusicPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("audio/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, PICK_AUDIO); }
        catch (Exception ex) { notifyUser("Не удалось открыть выбор музыки"); }
    }

    private void stopMusic() {
        if (backgroundMusic != null) {
            try { backgroundMusic.stop(); } catch (Exception ignored) {}
            backgroundMusic.release(); backgroundMusic = null;
        }
    }

    private void startSavedMusic() {
        stopMusic();
        if (!prefs().getBoolean("musicEnabled", true)) return;
        String uri = prefs().getString("musicUri", "");
        try {
            if (uri.isEmpty()) {
                // Original, freely redistributable Tengu theme packaged with the application.
                backgroundMusic = MediaPlayer.create(this, R.raw.tengu_theme);
                if (backgroundMusic == null) throw new IllegalStateException("Нет встроенной мелодии");
                backgroundMusic.setLooping(true);
                backgroundMusic.setVolume(0.18f, 0.18f);
                backgroundMusic.start();
                return;
            }
            MediaPlayer p = new MediaPlayer();
            p.setDataSource(this, Uri.parse(uri));
            p.setLooping(true);
            p.setVolume(0.25f, 0.25f);
            p.setOnPreparedListener(MediaPlayer::start);
            p.setOnErrorListener((mp, what, extra) -> { notifyUser("Ошибка воспроизведения музыки"); return true; });
            backgroundMusic = p;
            p.prepareAsync();
        } catch (Exception e) { notifyUser("Не удалось открыть выбранную музыку"); stopMusic(); }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == PICK_AUDIO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) {}
            prefs().edit().putString("musicUri",uri.toString()).putBoolean("musicEnabled",true).apply();
            startSavedMusic(); notifyUser("Музыка выбрана. Её можно отключить в настройках.");
        }
        if (requestCode == PICK_MODEL && resultCode == RESULT_OK && data != null && data.getData() != null) {
            importModel(data.getData());
        }
        if(requestCode==PICK_FILE && pendingFiles!=null){
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode,data);
            pendingFiles.onReceiveValue(result);
            pendingFiles=null;
        }
    }

    /** Local text inference ONLY. The target address is fixed and cannot be supplied by web JavaScript. */
    private File modelFile() { return new File(new File(getFilesDir(), "models"), MODEL_NAME); }

    private void openModelPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(intent, PICK_MODEL); }
        catch (Exception ex) { notifyUser("Не удалось открыть выбор GGUF"); }
    }

    /** Copy the user's GGUF into app-private storage. The old model remains until a complete copy. */
    private void importModel(Uri source) {
        engineQueue.execute(() -> {
            File destination = modelFile();
            File folder = destination.getParentFile();
            File temp = new File(folder, MODEL_NAME + ".partial");
            long total = 0;
            try {
                if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Нет папки модели");
                if (temp.exists()) temp.delete();
                try (InputStream input = getContentResolver().openInputStream(source);
                     OutputStream output = new FileOutputStream(temp)) {
                    if (input == null) throw new IllegalStateException("Не удалось открыть файл");
                    byte[] buffer = new byte[256 * 1024];
                    int n;
                    while ((n = input.read(buffer)) != -1) {
                        total += n;
                        if (total > 6L * 1024 * 1024 * 1024) throw new IllegalStateException("Модель больше 6 ГБ");
                        output.write(buffer, 0, n);
                    }
                }
                if (total < 1024 * 1024) throw new IllegalStateException("Слишком маленькая модель GGUF");
                try (InputStream header = new java.io.FileInputStream(temp)) {
                    byte[] magic = new byte[4];
                    if (header.read(magic) != 4 || magic[0] != 'G' || magic[1] != 'G' || magic[2] != 'U' || magic[3] != 'F') {
                        throw new IllegalStateException("Выбранный файл не является GGUF");
                    }
                }
                if (LocalLlm.AVAILABLE) LocalLlm.unload();
                // Rename atomically within the same app-private volume.
                if (!temp.renameTo(destination)) {
                    java.nio.file.Files.move(temp.toPath(), destination.toPath(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }
                prefs().edit().putString("modelImported", destination.getName()).apply();
                notifyUser("GGUF импортирована: " + (total / 1024 / 1024) + " МБ. Можно задавать вопросы.");
            } catch (Exception ex) {
                temp.delete();
                notifyUser("Импорт модели не удался: " + ex.getMessage());
            }
        });
    }

    /** Inference is fully on-device through JNI. No HTTP requests are made for chat. */
    private String talkToLocalEngine(String payloadJson) throws Exception {
        if (!LocalLlm.AVAILABLE) throw new IllegalStateException("Нативная библиотека ИИ отсутствует в APK");
        File file = modelFile();
        if (!file.isFile()) throw new IllegalStateException("Выбери GGUF-модель в настройках Tengu");
        JSONObject payload = new JSONObject(payloadJson);
        JSONArray requested = payload.optJSONArray("messages");
        if (requested == null || requested.length() < 2 || requested.length() > 24)
            throw new IllegalArgumentException("Некорректная история диалога");
        String[] roles = new String[requested.length()];
        String[] contents = new String[requested.length()];
        for (int i = 0; i < requested.length(); i++) {
            JSONObject msg = requested.getJSONObject(i);
            String role = msg.optString("role", "");
            String content = msg.optString("content", "");
            if (!(role.equals("system") || role.equals("assistant") || role.equals("user")) || content.length() > 12000)
                throw new IllegalArgumentException("Некорректное сообщение или слишком длинный контекст");
            roles[i] = role; contents[i] = content;
        }
        int tokens = Math.max(32, Math.min(800, payload.optInt("max_tokens", 350)));
        int context = tokens > 450 ? 4096 : 2048;
        String error = LocalLlm.load(file.getAbsolutePath(), context);
        if (!error.isEmpty()) throw new IllegalStateException(error);
        String output = LocalLlm.generate(roles, contents, tokens);
        if (output == null || output.trim().isEmpty()) throw new IllegalStateException("Модель не вернула текст");
        return output;
    }

    private void replyToJs(String requestId, JSONObject reply) {
        if (!requestId.matches("t[0-9]{1,12}")) return;
        String js = "window.TenguRuntime&&window.TenguRuntime._respond(" + JSONObject.quote(requestId) + "," + JSONObject.quote(reply.toString()) + ");";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private class TenguBridge {
        @JavascriptInterface public boolean musicEnabled() { return prefs().getBoolean("musicEnabled",true); }
        @JavascriptInterface public void downloadModel() { runOnUiThread(() -> downloadOfficialModel()); }
        @JavascriptInterface public boolean isModelDownloading() { return isDownloadingModel; }
        @JavascriptInterface public void openSearch(String engine, String query) {
            runOnUiThread(() -> {
                if(query==null||query.trim().isEmpty()||query.length()>300)return;
                String base;
                if("google".equals(engine))base="https://www.google.com/search?q=";
                else if("bing".equals(engine))base="https://www.bing.com/search?q=";
                else if("duckduckgo".equals(engine))base="https://duckduckgo.com/?q=";
                else return;
                try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(base+Uri.encode(query)))); }
                catch(Exception ex){ notifyUser("Не удалось открыть браузер"); }
            });
        }
        @JavascriptInterface public void nativeHttp(String requestId, String payload) {
            if(requestId==null||!requestId.matches("t[0-9]{1,12}"))return;
            networkQueue.execute(() -> {
                JSONObject response;
                try{ response=fetchPublicData(new JSONObject(payload)); }
                catch(Exception ex) {
                    response=new JSONObject();
                    try{response.put("ok",false);response.put("error", "Сеть: "+ex.getMessage());}
                    catch(Exception ignored){}
                }
                replyToJs(requestId,response);
            });
        }
        @JavascriptInterface public boolean musicConfigured() { return !prefs().getString("musicUri","").isEmpty(); }
        @JavascriptInterface public void pickMusic() { runOnUiThread(() -> openMusicPicker()); }
        @JavascriptInterface public void setMusicEnabled(boolean enabled) {
            prefs().edit().putBoolean("musicEnabled",enabled).apply();
            runOnUiThread(() -> { if(enabled)startSavedMusic();else stopMusic(); });
        }

        @JavascriptInterface public void localGenerate(String requestId, String payload) {
            if (requestId == null || !requestId.matches("t[0-9]{1,12}")) return;
            engineQueue.execute(() -> {
                JSONObject result = new JSONObject();
                try {
                    String answer = talkToLocalEngine(payload);
                    result.put("ok", true);
                    result.put("text", answer);
                } catch (Exception ex) {
                    try { result.put("ok", false); result.put("error", "Tengu не смогла сформировать локальный ответ. " + ex.getMessage()); }
                    catch (Exception ignored) { }
                }
                replyToJs(requestId, result);
            });
        }
        @JavascriptInterface public void pickModel() { runOnUiThread(() -> openModelPicker()); }
        @JavascriptInterface public String modelName() {
            File model = modelFile();
            return model.isFile() ? "GGUF · " + (model.length() / 1024 / 1024) + " МБ" : "Модель не импортирована";
        }
        @JavascriptInterface public void localStatus(String requestId, String unused) {
            if (requestId == null || !requestId.matches("t[0-9]{1,12}")) return;
            engineQueue.execute(() -> {
                JSONObject response = new JSONObject();
                try {
                    if (!LocalLlm.AVAILABLE) throw new IllegalStateException("Нативная библиотека отсутствует");
                    if (!modelFile().isFile()) throw new IllegalStateException("GGUF не выбрана в настройках");
                    String error = LocalLlm.load(modelFile().getAbsolutePath(), 2048);
                    if (!error.isEmpty()) throw new IllegalStateException(error);
                    response.put("ok", true);
                    response.put("message", "GGUF загружена в движок: " + (modelFile().length() / 1024 / 1024) + " МБ");
                } catch(Exception ex) {
                    try { response.put("ok", false); response.put("error", ex.getMessage()); }
                    catch(Exception ignored) { }
                }
                replyToJs(requestId, response);
            });
        }
        @JavascriptInterface public void saveDataUrl(String url,String requestedName) {
            if (url == null || !url.startsWith("data:") || url.length() > 100_000_000) {
                notifyUser("Файл слишком большой или неверный формат"); return;
            }
            try {
                int comma=url.indexOf(',');
                if(comma<0)throw new IllegalArgumentException("Некорректный файл");
                String metadata=url.substring(5,comma);
                String mime=metadata.split(";",2)[0];
                if(mime.isEmpty())mime="application/octet-stream";
                byte[] bytes=android.util.Base64.decode(url.substring(comma+1), android.util.Base64.DEFAULT);
                String safe=(requestedName==null?"":requestedName).replaceAll("[^a-zA-Z0-9А-Яа-яЁё_.() -]","_");
                if(safe.isEmpty())safe="Tengu_export_"+System.currentTimeMillis();
                if(Build.VERSION.SDK_INT >= 29){
                    ContentValues values=new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME,safe);
                    values.put(MediaStore.MediaColumns.MIME_TYPE,mime);
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Tengu");
                    Uri destination=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                    if(destination==null)throw new IllegalStateException("Нет доступа к загрузкам");
                    try(OutputStream stream=getContentResolver().openOutputStream(destination)){
                        if(stream==null)throw new IllegalStateException("Не удалось открыть файл");
                        stream.write(bytes);
                    }
                    notifyUser("Сохранено в Загрузки/Tengu: "+safe);
                }else{
                    File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"Tengu");
                    if(!dir.exists() && !dir.mkdirs())throw new IllegalStateException("Нет папки");
                    try(FileOutputStream out=new FileOutputStream(new File(dir,safe))){out.write(bytes);}
                    notifyUser("Сохранено в папку Tengu приложения: "+safe);
                }
            } catch(Exception e){ Log.e("Tengu","Save failed",e);notifyUser("Ошибка сохранения: "+e.getMessage()); }
        }
    }
    /** Download the small official on-device model once. Resumable and SHA256 verified.
     * No chat text is sent to Hugging Face. Only the public model weights are fetched.
     */
    private void reportModelProgress(String message) {
        String js = "window.tenguModelProgress&&window.tenguModelProgress(" + JSONObject.quote(message) + ");";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }
    private String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = new java.io.FileInputStream(file)) {
            byte[] data = new byte[256 * 1024]; int n;
            while ((n = input.read(data)) > 0) digest.update(data,0,n);
        }
        StringBuilder out = new StringBuilder();
        for (byte b : digest.digest()) out.append(String.format(java.util.Locale.ROOT,"%02x", b & 0xff));
        return out.toString();
    }
    private void downloadOfficialModel() {
        if (isDownloadingModel) { notifyUser("Модель уже загружается"); return; }
        File folder=modelFile().getParentFile();
        if (!folder.exists() && !folder.mkdirs()) { notifyUser("Не удалось создать папку модели"); return; }
        if (modelFile().isFile()) { notifyUser("Модель уже установлена"); return; }
        StatFs stat = new StatFs(folder.getAbsolutePath());
        if (stat.getAvailableBytes() < OFFICIAL_MODEL_SIZE + 70L*1024*1024) {
            notifyUser("Для загрузки модели нужно около 600 МБ свободного места"); return;
        }
        isDownloadingModel = true;
        networkQueue.execute(() -> {
            File partial=new File(folder, MODEL_NAME + ".partial");
            try {
                long offset=partial.isFile()?partial.length():0;
                if(offset>OFFICIAL_MODEL_SIZE) { partial.delete(); offset=0; }
                reportModelProgress("Загрузка модели Qwen 0.5B · около 491 МБ");
                HttpURLConnection conn = (HttpURLConnection)new URL(OFFICIAL_MODEL_URL).openConnection();
                conn.setConnectTimeout(25000); conn.setReadTimeout(60000);
                conn.setRequestProperty("User-Agent","Tengu-Android/8.2");
                if(offset>0)conn.setRequestProperty("Range","bytes="+offset+"-");
                int status=conn.getResponseCode();
                if(status!=200&&status!=206)throw new IllegalStateException("Сервер модели вернул HTTP "+status);
                if(status==200)offset=0;
                long bytes=offset;
                long previousShown=-1;
                try(InputStream in=conn.getInputStream(); OutputStream out=new FileOutputStream(partial,offset>0)) {
                    byte[] buff=new byte[256*1024]; int n;
                    while((n=in.read(buff))!=-1){
                        if(Thread.currentThread().isInterrupted()) throw new IllegalStateException("Загрузка прервана");
                        bytes+=n;
                        if(bytes>OFFICIAL_MODEL_SIZE + 1024) throw new IllegalStateException("Размер модели не совпадает");
                        out.write(buff,0,n);
                        long progress=bytes*100/OFFICIAL_MODEL_SIZE;
                        if(progress/10>previousShown/10){previousShown=progress;reportModelProgress("Загрузка модели: "+progress+"%");}
                    }
                } finally { conn.disconnect(); }
                if(partial.length()!=OFFICIAL_MODEL_SIZE)throw new IllegalStateException("Модель загружена не полностью: "+partial.length()+" байт");
                reportModelProgress("Проверяю целостность GGUF...");
                if(!OFFICIAL_MODEL_SHA.equalsIgnoreCase(sha256(partial))){
                    partial.delete(); throw new IllegalStateException("Контрольная сумма не совпала, файл удалён");
                }
                if(!partial.renameTo(modelFile())) throw new IllegalStateException("Не удалось сохранить модель");
                prefs().edit().putString("modelImported","Qwen2.5-0.5B Q4_K_M").apply();
                reportModelProgress("Модель готова! Перейди в чат и задай вопрос.");
                notifyUser("Tengu готова к локальным ответам без интернета");
            }catch(Exception ex){
                reportModelProgress("Загрузка остановилась: "+ex.getMessage()+". Нажми кнопку ещё раз для продолжения.");
            }finally { isDownloadingModel=false; }
        });
    }

    /** Only explicitly selected public data providers; never an arbitrary URL. */
    private JSONObject fetchPublicData(JSONObject input) throws Exception {
        String raw=input.optString("url", "");
        URI uri = URI.create(raw);
        if(!"https".equalsIgnoreCase(uri.getScheme()) || uri.getUserInfo()!=null || uri.getPort()!=-1)
            throw new IllegalArgumentException("Разрешены только HTTPS-источники");
        String host=uri.getHost();
        if(host==null || !(host.equals("ru.wikipedia.org") || host.equals("en.wikipedia.org") ||
           host.equals("ru.wiktionary.org") || host.equals("www.wikidata.org") || host.equals("aihorde.net")))
            throw new IllegalArgumentException("Источник не разрешён");
        boolean horde=host.equals("aihorde.net");
        String method=input.optString("method", "GET").toUpperCase(java.util.Locale.ROOT);
        if(!method.equals("GET") && !(horde && method.equals("POST")))
            throw new IllegalArgumentException("Метод не разрешён");
        if(horde && !uri.getPath().startsWith("/api/v2/generate/"))
            throw new IllegalArgumentException("Недопустимая операция генератора");
        HttpURLConnection con=(HttpURLConnection)uri.toURL().openConnection();
        con.setConnectTimeout(18000); con.setReadTimeout(32000);
        con.setRequestMethod(method);
        con.setRequestProperty("User-Agent","Tengu-Android/8.2 (offline local AI; public knowledge lookup)");
        con.setRequestProperty("Accept", "application/json");
        if(horde){con.setRequestProperty("apikey","0000000000");con.setRequestProperty("Client-Agent","Tengu:8.2:community");}
        if(method.equals("POST")){
            String body=input.optString("body", "");
            if(body.length()>10000)throw new IllegalArgumentException("Слишком длинный запрос");
            con.setDoOutput(true);con.setRequestProperty("Content-Type","application/json");
            try(OutputStream o=con.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));}
        }
        int status=con.getResponseCode();
        InputStream stream=status>=400?con.getErrorStream():con.getInputStream();
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        if(stream!=null)try(InputStream source=stream){byte[] buffer=new byte[8192];int n;
            while((n=source.read(buffer))!=-1){
                if(bytes.size()+n>2_000_000)throw new IllegalArgumentException("Ответ сервиса слишком большой");
                bytes.write(buffer,0,n);
            }
        }
        con.disconnect();
        JSONObject response=new JSONObject();
        response.put("ok",true);response.put("status",status);
        response.put("body",bytes.toString("UTF-8"));
        return response;
    }

    private void notifyUser(String message){ runOnUiThread(()->Toast.makeText(this,message,Toast.LENGTH_LONG).show()); }
    @Override public void onBackPressed() {
        new AlertDialog.Builder(this).setTitle("Выйти из Tengu?")
                .setNegativeButton("Остаться",(dialog,which)->dialog.dismiss())
                .setPositiveButton("Выйти",(dialog,which)->finish()).show();
    }
    @Override protected void onPause() {
        if (backgroundMusic != null && backgroundMusic.isPlaying()) backgroundMusic.pause();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (backgroundMusic != null && prefs().getBoolean("musicEnabled", true)) {
            try { if (!backgroundMusic.isPlaying()) backgroundMusic.start(); } catch (Exception ignored) {}
        }
    }
    @Override protected void onDestroy(){
        if(pendingFiles!=null){pendingFiles.onReceiveValue(null);pendingFiles=null;}
        if(web!=null){web.removeJavascriptInterface("TenguNative");web.destroy();}
        engineQueue.shutdownNow();
        networkQueue.shutdownNow();
        stopMusic();
        super.onDestroy();
    }
}
